﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Eternal_Plague;

public class Game1 : Game
{
    private GraphicsDeviceManager _graphics;
    private SpriteBatch _spriteBatch;
    private Texture2D fumigador;
    private Vector2 posicion,origen;
    private float rotar;

    public Game1()
    {
        _graphics = new GraphicsDeviceManager(this);
        Content.RootDirectory = "Content";
        IsMouseVisible = true;
    }

    protected override void Initialize()
    {
        // TODO: Add your initialization logic here
        

        base.Initialize();
    }

    protected override void LoadContent()
    {
        _spriteBatch = new SpriteBatch(GraphicsDevice);
        fumigador=Content.Load<Texture2D>("imagen/New Piskel-1.png");
        posicion=new Vector2(100,100);
       
        // TODO: use this.Content to load your game content here
    }

    protected override void Update(GameTime gameTime)
    {
        if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
            Exit();
              var kstate = Keyboard.GetState();

    // Movimiento con WASD o flechas
    if (kstate.IsKeyDown(Keys.W) || kstate.IsKeyDown(Keys.Up))
    {
        posicion.Y = posicion.Y-1;
        rotar=0f;  
    }
    if (kstate.IsKeyDown(Keys.S) || kstate.IsKeyDown(Keys.Down))
    {
        posicion.Y = posicion.Y+1 ;
        rotar=3.1416f*1f; 
    }
    if (kstate.IsKeyDown(Keys.A) || kstate.IsKeyDown(Keys.Left))
    {
        posicion.X = posicion.X-1 ;
        rotar=3.1416f*1.5f; 
    }
    if (kstate.IsKeyDown(Keys.D) || kstate.IsKeyDown(Keys.Right))
    {
        posicion.X = posicion.X+1 ; 
        rotar=3.1416f*0.5f;
    }
        // TODO: Add your update logic here
        base.Update(gameTime);
    }

    protected override void Draw(GameTime gameTime)
    {
        GraphicsDevice.Clear(Color.CornflowerBlue);
         origen=new Vector2(fumigador.Width/2.0f,fumigador.Height/2.0f);
        _spriteBatch.Begin();
        _spriteBatch.Draw(fumigador,posicion,null,Color.White,rotar,origen,1.0f,SpriteEffects.None,0.0f);
        _spriteBatch.End();

        base.Draw(gameTime);
    }
}
