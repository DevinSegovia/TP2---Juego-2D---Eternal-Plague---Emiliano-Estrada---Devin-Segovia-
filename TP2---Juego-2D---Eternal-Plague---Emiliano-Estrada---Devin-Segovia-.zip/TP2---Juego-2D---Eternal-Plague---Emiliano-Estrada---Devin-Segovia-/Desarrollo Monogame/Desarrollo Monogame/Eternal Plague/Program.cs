﻿using var game = new Eternal_Plague.Game1();
game.Run();
