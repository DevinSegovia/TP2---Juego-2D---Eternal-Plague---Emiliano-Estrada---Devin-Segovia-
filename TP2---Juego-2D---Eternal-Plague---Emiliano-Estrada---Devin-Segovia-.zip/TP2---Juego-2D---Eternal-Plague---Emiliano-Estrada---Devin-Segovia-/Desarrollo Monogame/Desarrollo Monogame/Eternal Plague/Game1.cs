﻿using System.Security.Cryptography.X509Certificates;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Eternal_Plague;

public class Game1 : Game
{
    private GraphicsDeviceManager _graphics;
    private SpriteBatch _spriteBatch;
    private Texture2D fumigador;
    private Vector2 posicion;
    private float velocidad = 200f;
    private float rotar=0f;

    public Game1()
    {
        _graphics = new GraphicsDeviceManager(this);
        Content.RootDirectory = "Content";
        IsMouseVisible = true;
    }

    protected override void Initialize()
    {
        posicion=new Vector2(100,100);
        // TODO: Add your initialization logic here

        base.Initialize();
    }

    protected override void LoadContent()
    {
        _spriteBatch = new SpriteBatch(GraphicsDevice);

        fumigador=Content.Load<Texture2D>("imagen/fumigador");
        // TODO: use this.Content to load your game content here
    }

    protected override void Update(GameTime gameTime)
    {
        KeyboardState Tecla = Keyboard.GetState();

        // 2. Calcular el tiempo transcurrido desde el último frame (en segundos)
        float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

        // 3. Crear un vector de dirección basado en las teclas presionadas
        Vector2 direccion = Vector2.Zero;

        if (Tecla.IsKeyDown(Keys.W) || Tecla.IsKeyDown(Keys.Up)){
            direccion.Y -= 1;
            rotar=0f;
        }

        if (Tecla.IsKeyDown(Keys.S) || Tecla.IsKeyDown(Keys.Down)){
            direccion.Y += 1;
            rotar=3.14159265f;
        }

        if (Tecla.IsKeyDown(Keys.A) || Tecla.IsKeyDown(Keys.Left)){
            direccion.X -= 1;
            rotar=3.14159265f*1.5f;
        }
        if (Tecla.IsKeyDown(Keys.D) || Tecla.IsKeyDown(Keys.Right)){
            direccion.X += 1;
            rotar=3.14159265f*0.5f;
        }
        // 4. Normalizar la dirección si hay movimiento diagonal
        if (direccion != Vector2.Zero)
        {
            direccion.Normalize();
        }
        posicion += direccion * velocidad * deltaTime;
        if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
            Exit();

        // TODO: Add your update logic here

        base.Update(gameTime);
    }

    protected override void Draw(GameTime gameTime)
    {
        GraphicsDevice.Clear(Color.CornflowerBlue);
        Vector2 origen = new Vector2(fumigador.Width / 2f, fumigador.Height / 2f);

        // TODO: Add your drawing code here
        _spriteBatch.Begin();
        _spriteBatch.Draw(fumigador,posicion,null,Color.White,rotar,origen,1.0f,SpriteEffects.None,0f);
        _spriteBatch.End();

        base.Draw(gameTime);
    }
}
